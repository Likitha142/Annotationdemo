package likhitha.AnnotationDemo;

import jakarta.persistence.Column; 
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Employee")   // optional, but makes table name explicit
public class Employee {

    @Id
    private int eid;

    @Column(length = 100)   // default is 255, you can adjust
    private String ename;

    @Column
    private int esal;

    // Default constructor (Hibernate needs this)
    public Employee() {}

    // Parameterized constructor
    public Employee(int eid, String ename, int esal) {
        this.eid = eid;
        this.ename = ename;
        this.esal = esal;
    }

    // Getters and setters
    public int getEid() { return eid; }
    public void setEid(int eid) { this.eid = eid; }

    public String getEname() { return ename; }
    public void setEname(String ename) { this.ename = ename; }

    public int getEsal() { return esal; }
    public void setEsal(int esal) { this.esal = esal; }
}